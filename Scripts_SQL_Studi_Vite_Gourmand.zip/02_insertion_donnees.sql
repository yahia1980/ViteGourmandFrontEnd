-- Vite & Gourmand - jeu de demonstration issu des fichiers fournis.
-- Prix et horaires de demonstration, non valides comme tarifs/horaires reels.
-- Executer APRES 01_creation_base.sql sur une base de test VIDE.
-- Ne contient ni donnees personnelles ni empreintes de mots de passe.
SET NAMES utf8mb4;
START TRANSACTION;

INSERT INTO `regime` (`id`, `nom`) VALUES (1, 'Classique'), (2, 'Végétarien'), (3, 'Végan');
INSERT INTO `theme` (`id`, `nom`) VALUES (1, 'Noël');

INSERT INTO theme (nom) SELECT 'Mariage' WHERE NOT EXISTS (SELECT 1 FROM theme WHERE nom = 'Mariage');
INSERT INTO theme (nom) SELECT 'Anniversaire' WHERE NOT EXISTS (SELECT 1 FROM theme WHERE nom = 'Anniversaire');
INSERT INTO theme (nom) SELECT 'Entreprise' WHERE NOT EXISTS (SELECT 1 FROM theme WHERE nom = 'Entreprise');
INSERT INTO theme (nom) SELECT 'Pâques' WHERE NOT EXISTS (SELECT 1 FROM theme WHERE nom = 'Pâques');
INSERT INTO theme (nom) SELECT 'Réception' WHERE NOT EXISTS (SELECT 1 FROM theme WHERE nom = 'Réception');
INSERT INTO theme (nom) SELECT 'Fêtes de fin d’année' WHERE NOT EXISTS (SELECT 1 FROM theme WHERE nom = 'Fêtes de fin d’année');
INSERT INTO regime (nom) SELECT 'Sans gluten' WHERE NOT EXISTS (SELECT 1 FROM regime WHERE nom = 'Sans gluten');
INSERT INTO regime (nom) SELECT 'Sans lactose' WHERE NOT EXISTS (SELECT 1 FROM regime WHERE nom = 'Sans lactose');
INSERT INTO regime (nom) SELECT 'Halal' WHERE NOT EXISTS (SELECT 1 FROM regime WHERE nom = 'Halal');
INSERT INTO menu (titre, description, nombre_personnes_min, prix, stock_disponible, conditions, theme_id, regime_id) SELECT 'Menu de Noël traditionnel', 'Repas de fête avec entrée, plat et dessert.', 6, 39.90, 30, 'Commande 72 h avant la prestation.', (SELECT id FROM theme WHERE nom='Noël' ORDER BY id LIMIT 1), (SELECT id FROM regime WHERE nom='Classique' ORDER BY id LIMIT 1) WHERE NOT EXISTS (SELECT 1 FROM menu WHERE titre='Menu de Noël traditionnel');
INSERT INTO menu (titre, description, nombre_personnes_min, prix, stock_disponible, conditions, theme_id, regime_id) SELECT 'Menu de Noël végétarien', 'Repas de fête végétarien, entrée, plat et dessert.', 6, 36.90, 20, 'Commande 72 h avant la prestation.', (SELECT id FROM theme WHERE nom='Noël' ORDER BY id LIMIT 1), (SELECT id FROM regime WHERE nom='Végétarien' ORDER BY id LIMIT 1) WHERE NOT EXISTS (SELECT 1 FROM menu WHERE titre='Menu de Noël végétarien');
INSERT INTO menu (titre, description, nombre_personnes_min, prix, stock_disponible, conditions, theme_id, regime_id) SELECT 'Menu de mariage prestige', 'Menu festif pour réception de mariage.', 20, 59.90, 100, 'Commande 14 jours avant la prestation.', (SELECT id FROM theme WHERE nom='Mariage' ORDER BY id LIMIT 1), (SELECT id FROM regime WHERE nom='Classique' ORDER BY id LIMIT 1) WHERE NOT EXISTS (SELECT 1 FROM menu WHERE titre='Menu de mariage prestige');
INSERT INTO menu (titre, description, nombre_personnes_min, prix, stock_disponible, conditions, theme_id, regime_id) SELECT 'Menu anniversaire gourmand', 'Formule conviviale pour célébrer un anniversaire.', 8, 29.90, 50, 'Commande 5 jours avant la prestation.', (SELECT id FROM theme WHERE nom='Anniversaire' ORDER BY id LIMIT 1), (SELECT id FROM regime WHERE nom='Classique' ORDER BY id LIMIT 1) WHERE NOT EXISTS (SELECT 1 FROM menu WHERE titre='Menu anniversaire gourmand');
INSERT INTO menu (titre, description, nombre_personnes_min, prix, stock_disponible, conditions, theme_id, regime_id) SELECT 'Menu entreprise', 'Déjeuner professionnel avec entrée, plat et dessert.', 10, 24.90, 80, 'Commande 5 jours avant la prestation.', (SELECT id FROM theme WHERE nom='Entreprise' ORDER BY id LIMIT 1), (SELECT id FROM regime WHERE nom='Classique' ORDER BY id LIMIT 1) WHERE NOT EXISTS (SELECT 1 FROM menu WHERE titre='Menu entreprise');
INSERT INTO menu (titre, description, nombre_personnes_min, prix, stock_disponible, conditions, theme_id, regime_id) SELECT 'Menu végétarien de saison', 'Cuisine de saison sans viande ni poisson.', 4, 27.90, 35, 'Commande 72 h avant la prestation.', (SELECT id FROM theme WHERE nom='Réception' ORDER BY id LIMIT 1), (SELECT id FROM regime WHERE nom='Végétarien' ORDER BY id LIMIT 1) WHERE NOT EXISTS (SELECT 1 FROM menu WHERE titre='Menu végétarien de saison');
INSERT INTO menu (titre, description, nombre_personnes_min, prix, stock_disponible, conditions, theme_id, regime_id) SELECT 'Menu végan découverte', 'Formule végétale avec entrée, plat et dessert.', 4, 28.90, 35, 'Commande 72 h avant la prestation.', (SELECT id FROM theme WHERE nom='Réception' ORDER BY id LIMIT 1), (SELECT id FROM regime WHERE nom='Végan' ORDER BY id LIMIT 1) WHERE NOT EXISTS (SELECT 1 FROM menu WHERE titre='Menu végan découverte');
INSERT INTO menu (titre, description, nombre_personnes_min, prix, stock_disponible, conditions, theme_id, regime_id) SELECT 'Menu de Pâques', 'Repas de printemps pour les fêtes de Pâques.', 6, 37.90, 25, 'Commande 5 jours avant la prestation.', (SELECT id FROM theme WHERE nom='Pâques' ORDER BY id LIMIT 1), (SELECT id FROM regime WHERE nom='Classique' ORDER BY id LIMIT 1) WHERE NOT EXISTS (SELECT 1 FROM menu WHERE titre='Menu de Pâques');
INSERT INTO plat (nom, description, categorie) SELECT 'Velouté de potimarron', 'Crème de potimarron et graines torréfiées', 'entree' WHERE NOT EXISTS (SELECT 1 FROM plat WHERE nom = 'Velouté de potimarron');
INSERT INTO plat (nom, description, categorie) SELECT 'Saumon fumé et citron', 'Assiette de saumon fumé', 'entree' WHERE NOT EXISTS (SELECT 1 FROM plat WHERE nom = 'Saumon fumé et citron');
INSERT INTO plat (nom, description, categorie) SELECT 'Salade de saison', 'Salade de légumes frais', 'entree' WHERE NOT EXISTS (SELECT 1 FROM plat WHERE nom = 'Salade de saison');
INSERT INTO plat (nom, description, categorie) SELECT 'Foie gras et chutney', 'Foie gras accompagné de chutney', 'entree' WHERE NOT EXISTS (SELECT 1 FROM plat WHERE nom = 'Foie gras et chutney');
INSERT INTO plat (nom, description, categorie) SELECT 'Suprême de volaille', 'Volaille et légumes de saison', 'plat' WHERE NOT EXISTS (SELECT 1 FROM plat WHERE nom = 'Suprême de volaille');
INSERT INTO plat (nom, description, categorie) SELECT 'Rôti de bœuf', 'Rôti et pommes de terre', 'plat' WHERE NOT EXISTS (SELECT 1 FROM plat WHERE nom = 'Rôti de bœuf');
INSERT INTO plat (nom, description, categorie) SELECT 'Risotto aux champignons', 'Risotto crémeux aux champignons', 'plat' WHERE NOT EXISTS (SELECT 1 FROM plat WHERE nom = 'Risotto aux champignons');
INSERT INTO plat (nom, description, categorie) SELECT 'Curry de légumes et riz', 'Curry de légumes au lait de coco', 'plat' WHERE NOT EXISTS (SELECT 1 FROM plat WHERE nom = 'Curry de légumes et riz');
INSERT INTO plat (nom, description, categorie) SELECT 'Tarte aux légumes', 'Tarte salée aux légumes', 'plat' WHERE NOT EXISTS (SELECT 1 FROM plat WHERE nom = 'Tarte aux légumes');
INSERT INTO plat (nom, description, categorie) SELECT 'Bûche chocolat', 'Dessert de fête au chocolat', 'dessert' WHERE NOT EXISTS (SELECT 1 FROM plat WHERE nom = 'Bûche chocolat');
INSERT INTO plat (nom, description, categorie) SELECT 'Tarte aux fruits', 'Tarte aux fruits de saison', 'dessert' WHERE NOT EXISTS (SELECT 1 FROM plat WHERE nom = 'Tarte aux fruits');
INSERT INTO plat (nom, description, categorie) SELECT 'Mousse chocolat végétale', 'Mousse au chocolat sans produits animaux', 'dessert' WHERE NOT EXISTS (SELECT 1 FROM plat WHERE nom = 'Mousse chocolat végétale');
INSERT INTO plat (nom, description, categorie) SELECT 'Gâteau anniversaire', 'Gâteau à partager', 'dessert' WHERE NOT EXISTS (SELECT 1 FROM plat WHERE nom = 'Gâteau anniversaire');
INSERT INTO allergene (nom) SELECT 'Gluten' WHERE NOT EXISTS (SELECT 1 FROM allergene WHERE nom = 'Gluten');
INSERT INTO allergene (nom) SELECT 'Lait' WHERE NOT EXISTS (SELECT 1 FROM allergene WHERE nom = 'Lait');
INSERT INTO allergene (nom) SELECT 'Œufs' WHERE NOT EXISTS (SELECT 1 FROM allergene WHERE nom = 'Œufs');
INSERT INTO allergene (nom) SELECT 'Poisson' WHERE NOT EXISTS (SELECT 1 FROM allergene WHERE nom = 'Poisson');
INSERT INTO allergene (nom) SELECT 'Fruits à coque' WHERE NOT EXISTS (SELECT 1 FROM allergene WHERE nom = 'Fruits à coque');
INSERT INTO allergene (nom) SELECT 'Soja' WHERE NOT EXISTS (SELECT 1 FROM allergene WHERE nom = 'Soja');
INSERT INTO allergene (nom) SELECT 'Céleri' WHERE NOT EXISTS (SELECT 1 FROM allergene WHERE nom = 'Céleri');
INSERT INTO allergene (nom) SELECT 'Moutarde' WHERE NOT EXISTS (SELECT 1 FROM allergene WHERE nom = 'Moutarde');
INSERT INTO allergene (nom) SELECT 'Sésame' WHERE NOT EXISTS (SELECT 1 FROM allergene WHERE nom = 'Sésame');
INSERT INTO allergene (nom) SELECT 'Crustacés' WHERE NOT EXISTS (SELECT 1 FROM allergene WHERE nom = 'Crustacés');
INSERT INTO allergene (nom) SELECT 'Mollusques' WHERE NOT EXISTS (SELECT 1 FROM allergene WHERE nom = 'Mollusques');
INSERT INTO allergene (nom) SELECT 'Arachides' WHERE NOT EXISTS (SELECT 1 FROM allergene WHERE nom = 'Arachides');
INSERT INTO allergene (nom) SELECT 'Sulfites' WHERE NOT EXISTS (SELECT 1 FROM allergene WHERE nom = 'Sulfites');
INSERT INTO allergene (nom) SELECT 'Lupin' WHERE NOT EXISTS (SELECT 1 FROM allergene WHERE nom = 'Lupin');
INSERT INTO plat_menu (plat_id, menu_id) SELECT p.id, m.id FROM plat p JOIN menu m ON m.titre='Menu de Noël traditionnel' WHERE p.nom='Foie gras et chutney' AND NOT EXISTS (SELECT 1 FROM plat_menu pm WHERE pm.plat_id=p.id AND pm.menu_id=m.id);
INSERT INTO plat_menu (plat_id, menu_id) SELECT p.id, m.id FROM plat p JOIN menu m ON m.titre='Menu de Noël traditionnel' WHERE p.nom='Suprême de volaille' AND NOT EXISTS (SELECT 1 FROM plat_menu pm WHERE pm.plat_id=p.id AND pm.menu_id=m.id);
INSERT INTO plat_menu (plat_id, menu_id) SELECT p.id, m.id FROM plat p JOIN menu m ON m.titre='Menu de Noël traditionnel' WHERE p.nom='Bûche chocolat' AND NOT EXISTS (SELECT 1 FROM plat_menu pm WHERE pm.plat_id=p.id AND pm.menu_id=m.id);
INSERT INTO plat_menu (plat_id, menu_id) SELECT p.id, m.id FROM plat p JOIN menu m ON m.titre='Menu de Noël végétarien' WHERE p.nom='Velouté de potimarron' AND NOT EXISTS (SELECT 1 FROM plat_menu pm WHERE pm.plat_id=p.id AND pm.menu_id=m.id);
INSERT INTO plat_menu (plat_id, menu_id) SELECT p.id, m.id FROM plat p JOIN menu m ON m.titre='Menu de Noël végétarien' WHERE p.nom='Risotto aux champignons' AND NOT EXISTS (SELECT 1 FROM plat_menu pm WHERE pm.plat_id=p.id AND pm.menu_id=m.id);
INSERT INTO plat_menu (plat_id, menu_id) SELECT p.id, m.id FROM plat p JOIN menu m ON m.titre='Menu de Noël végétarien' WHERE p.nom='Tarte aux fruits' AND NOT EXISTS (SELECT 1 FROM plat_menu pm WHERE pm.plat_id=p.id AND pm.menu_id=m.id);
INSERT INTO plat_menu (plat_id, menu_id) SELECT p.id, m.id FROM plat p JOIN menu m ON m.titre='Menu de mariage prestige' WHERE p.nom='Saumon fumé et citron' AND NOT EXISTS (SELECT 1 FROM plat_menu pm WHERE pm.plat_id=p.id AND pm.menu_id=m.id);
INSERT INTO plat_menu (plat_id, menu_id) SELECT p.id, m.id FROM plat p JOIN menu m ON m.titre='Menu de mariage prestige' WHERE p.nom='Rôti de bœuf' AND NOT EXISTS (SELECT 1 FROM plat_menu pm WHERE pm.plat_id=p.id AND pm.menu_id=m.id);
INSERT INTO plat_menu (plat_id, menu_id) SELECT p.id, m.id FROM plat p JOIN menu m ON m.titre='Menu de mariage prestige' WHERE p.nom='Tarte aux fruits' AND NOT EXISTS (SELECT 1 FROM plat_menu pm WHERE pm.plat_id=p.id AND pm.menu_id=m.id);
INSERT INTO plat_menu (plat_id, menu_id) SELECT p.id, m.id FROM plat p JOIN menu m ON m.titre='Menu anniversaire gourmand' WHERE p.nom='Salade de saison' AND NOT EXISTS (SELECT 1 FROM plat_menu pm WHERE pm.plat_id=p.id AND pm.menu_id=m.id);
INSERT INTO plat_menu (plat_id, menu_id) SELECT p.id, m.id FROM plat p JOIN menu m ON m.titre='Menu anniversaire gourmand' WHERE p.nom='Suprême de volaille' AND NOT EXISTS (SELECT 1 FROM plat_menu pm WHERE pm.plat_id=p.id AND pm.menu_id=m.id);
INSERT INTO plat_menu (plat_id, menu_id) SELECT p.id, m.id FROM plat p JOIN menu m ON m.titre='Menu anniversaire gourmand' WHERE p.nom='Gâteau anniversaire' AND NOT EXISTS (SELECT 1 FROM plat_menu pm WHERE pm.plat_id=p.id AND pm.menu_id=m.id);
INSERT INTO plat_menu (plat_id, menu_id) SELECT p.id, m.id FROM plat p JOIN menu m ON m.titre='Menu entreprise' WHERE p.nom='Salade de saison' AND NOT EXISTS (SELECT 1 FROM plat_menu pm WHERE pm.plat_id=p.id AND pm.menu_id=m.id);
INSERT INTO plat_menu (plat_id, menu_id) SELECT p.id, m.id FROM plat p JOIN menu m ON m.titre='Menu entreprise' WHERE p.nom='Rôti de bœuf' AND NOT EXISTS (SELECT 1 FROM plat_menu pm WHERE pm.plat_id=p.id AND pm.menu_id=m.id);
INSERT INTO plat_menu (plat_id, menu_id) SELECT p.id, m.id FROM plat p JOIN menu m ON m.titre='Menu entreprise' WHERE p.nom='Tarte aux fruits' AND NOT EXISTS (SELECT 1 FROM plat_menu pm WHERE pm.plat_id=p.id AND pm.menu_id=m.id);
INSERT INTO plat_menu (plat_id, menu_id) SELECT p.id, m.id FROM plat p JOIN menu m ON m.titre='Menu végétarien de saison' WHERE p.nom='Velouté de potimarron' AND NOT EXISTS (SELECT 1 FROM plat_menu pm WHERE pm.plat_id=p.id AND pm.menu_id=m.id);
INSERT INTO plat_menu (plat_id, menu_id) SELECT p.id, m.id FROM plat p JOIN menu m ON m.titre='Menu végétarien de saison' WHERE p.nom='Tarte aux légumes' AND NOT EXISTS (SELECT 1 FROM plat_menu pm WHERE pm.plat_id=p.id AND pm.menu_id=m.id);
INSERT INTO plat_menu (plat_id, menu_id) SELECT p.id, m.id FROM plat p JOIN menu m ON m.titre='Menu végétarien de saison' WHERE p.nom='Tarte aux fruits' AND NOT EXISTS (SELECT 1 FROM plat_menu pm WHERE pm.plat_id=p.id AND pm.menu_id=m.id);
INSERT INTO plat_menu (plat_id, menu_id) SELECT p.id, m.id FROM plat p JOIN menu m ON m.titre='Menu végan découverte' WHERE p.nom='Salade de saison' AND NOT EXISTS (SELECT 1 FROM plat_menu pm WHERE pm.plat_id=p.id AND pm.menu_id=m.id);
INSERT INTO plat_menu (plat_id, menu_id) SELECT p.id, m.id FROM plat p JOIN menu m ON m.titre='Menu végan découverte' WHERE p.nom='Curry de légumes et riz' AND NOT EXISTS (SELECT 1 FROM plat_menu pm WHERE pm.plat_id=p.id AND pm.menu_id=m.id);
INSERT INTO plat_menu (plat_id, menu_id) SELECT p.id, m.id FROM plat p JOIN menu m ON m.titre='Menu végan découverte' WHERE p.nom='Mousse chocolat végétale' AND NOT EXISTS (SELECT 1 FROM plat_menu pm WHERE pm.plat_id=p.id AND pm.menu_id=m.id);
INSERT INTO plat_menu (plat_id, menu_id) SELECT p.id, m.id FROM plat p JOIN menu m ON m.titre='Menu de Pâques' WHERE p.nom='Velouté de potimarron' AND NOT EXISTS (SELECT 1 FROM plat_menu pm WHERE pm.plat_id=p.id AND pm.menu_id=m.id);
INSERT INTO plat_menu (plat_id, menu_id) SELECT p.id, m.id FROM plat p JOIN menu m ON m.titre='Menu de Pâques' WHERE p.nom='Suprême de volaille' AND NOT EXISTS (SELECT 1 FROM plat_menu pm WHERE pm.plat_id=p.id AND pm.menu_id=m.id);
INSERT INTO plat_menu (plat_id, menu_id) SELECT p.id, m.id FROM plat p JOIN menu m ON m.titre='Menu de Pâques' WHERE p.nom='Tarte aux fruits' AND NOT EXISTS (SELECT 1 FROM plat_menu pm WHERE pm.plat_id=p.id AND pm.menu_id=m.id);
INSERT INTO horaire (jour, heure_ouverture, heure_fermeture, ferme) SELECT 'Lundi', '09:00:00', '18:00:00', 0 WHERE NOT EXISTS (SELECT 1 FROM horaire WHERE jour='Lundi');
INSERT INTO horaire (jour, heure_ouverture, heure_fermeture, ferme) SELECT 'Mardi', '09:00:00', '18:00:00', 0 WHERE NOT EXISTS (SELECT 1 FROM horaire WHERE jour='Mardi');
INSERT INTO horaire (jour, heure_ouverture, heure_fermeture, ferme) SELECT 'Mercredi', '09:00:00', '18:00:00', 0 WHERE NOT EXISTS (SELECT 1 FROM horaire WHERE jour='Mercredi');
INSERT INTO horaire (jour, heure_ouverture, heure_fermeture, ferme) SELECT 'Jeudi', '09:00:00', '18:00:00', 0 WHERE NOT EXISTS (SELECT 1 FROM horaire WHERE jour='Jeudi');
INSERT INTO horaire (jour, heure_ouverture, heure_fermeture, ferme) SELECT 'Vendredi', '09:00:00', '18:00:00', 0 WHERE NOT EXISTS (SELECT 1 FROM horaire WHERE jour='Vendredi');
INSERT INTO horaire (jour, heure_ouverture, heure_fermeture, ferme) SELECT 'Samedi', '10:00:00', '17:00:00', 0 WHERE NOT EXISTS (SELECT 1 FROM horaire WHERE jour='Samedi');
INSERT INTO horaire (jour, heure_ouverture, heure_fermeture, ferme) SELECT 'Dimanche', NULL, NULL, 1 WHERE NOT EXISTS (SELECT 1 FROM horaire WHERE jour='Dimanche');

-- Menus et chemins d'images du fichier import_menus_images_alwaysdata.
INSERT INTO menu (titre, description, nombre_personnes_min, prix, stock_disponible, conditions, theme_id, regime_id)
SELECT 'Le BourguiMaison', 'Bœuf mariné au soja et gingembre, Slade, Tiramisu.', 6, 147.00, 8, 'Commande à confirmer selon les disponibilités. Conditions de livraison à préciser.', 1, 1
WHERE NOT EXISTS (SELECT 1 FROM menu WHERE titre = 'Le BourguiMaison');
INSERT INTO menu (titre, description, nombre_personnes_min, prix, stock_disponible, conditions, theme_id, regime_id)
SELECT 'La FruitésDesMer', 'Saumon fumé,  salade, moussre au chocolat.', 5, 66.00, 10, 'Conserver au frais. Conditions de livraison à préciser.', 3, 2
WHERE NOT EXISTS (SELECT 1 FROM menu WHERE titre = 'La FruitésDesMer');
INSERT INTO menu (titre, description, nombre_personnes_min, prix, stock_disponible, conditions, theme_id, regime_id)
SELECT 'le Magic', 'Salade composée, Poulet rôti, Tarte aux pommes.', 4, 85.00, 10, 'Conditions de conservation, réchauffage et livraison à préciser.', 2, 1
WHERE NOT EXISTS (SELECT 1 FROM menu WHERE titre = 'le Magic');
INSERT INTO menu (titre, description, nombre_personnes_min, prix, stock_disponible, conditions, theme_id, regime_id)
SELECT 'Le Magistralr', 'La spécialité du chef', 6, 120.00, 10, 'Menu', 2, 1
WHERE NOT EXISTS (SELECT 1 FROM menu WHERE titre = 'Le Magistralr');
INSERT INTO menu_image (chemin, menu_id)
SELECT '/images/imagesGaleries/img4.jpg', m.id FROM menu m
WHERE m.titre = 'Le BourguiMaison'
AND NOT EXISTS (SELECT 1 FROM menu_image mi WHERE mi.menu_id = m.id AND mi.chemin = '/images/imagesGaleries/img4.jpg');
INSERT INTO menu_image (chemin, menu_id)
SELECT '/images/imagesGaleries/img3.jpg', m.id FROM menu m
WHERE m.titre = 'La FruitésDesMer'
AND NOT EXISTS (SELECT 1 FROM menu_image mi WHERE mi.menu_id = m.id AND mi.chemin = '/images/imagesGaleries/img3.jpg');
INSERT INTO menu_image (chemin, menu_id)
SELECT '/images/imagesGaleries/img1.jpg', m.id FROM menu m
WHERE m.titre = 'le Magic'
AND NOT EXISTS (SELECT 1 FROM menu_image mi WHERE mi.menu_id = m.id AND mi.chemin = '/images/imagesGaleries/img1.jpg');
INSERT INTO menu_image (chemin, menu_id)
SELECT '/images/uploads/imagesMenus/cdb61e8c9b0c523f9aaf8c0cf966db78.jpg', m.id FROM menu m
WHERE m.titre = 'Le Magistralr'
AND NOT EXISTS (SELECT 1 FROM menu_image mi WHERE mi.menu_id = m.id AND mi.chemin = '/images/uploads/imagesMenus/cdb61e8c9b0c523f9aaf8c0cf966db78.jpg');
COMMIT;
